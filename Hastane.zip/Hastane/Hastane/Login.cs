﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hastane
{
    public partial class Login : Form

    {
        private const string CorrectUsername = "admin";
        private const string CorrectPassword = "password";
        public Login()
        {
            InitializeComponent();
            txtsifre.UseSystemPasswordChar = false;
        }
        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtkullanici.Text;
            string password = txtsifre.Text;


            if (txtkullanici.Text == "admin" && txtsifre.Text == "12345")
           
                    {
                MessageBox.Show("Giriş başarılı!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }

            else
            {
                MessageBox.Show("Geçersiz kullanıcı adı veya şifre!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);


            }
        }
       


        private void button2_Click(object sender, EventArgs e)
        {
            txtkullanici.Text = string.Empty;
            txtsifre.Text = string.Empty;
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            HastaGirisi hastaGirisi = new HastaGirisi();
            hastaGirisi.Show();
            this.Hide();
        }
    }
}


