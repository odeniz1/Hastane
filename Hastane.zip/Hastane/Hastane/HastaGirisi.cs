﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hastane
{
    public partial class HastaGirisi : Form
    {
        public HastaGirisi()
        {
            InitializeComponent();
        }

        DataTable tablo = new DataTable();

        private void HastaGirisi_Load(object sender, EventArgs e)
        {
            tablo.Columns.Add("HstAdSoyad", typeof(string));
            tablo.Columns.Add("HstTcKimlik", typeof(string));
            tablo.Columns.Add("HstYas", typeof(int));
            tablo.Columns.Add("HstCinsiyet", typeof(string));
            tablo.Columns.Add("HstTelefon", typeof(string));
            tablo.Columns.Add("HstKanGrubu", typeof(string));
            tablo.Columns.Add("HstSikayet",typeof(string));
            dataGridView1.DataSource = tablo;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            tablo.Rows.Add(txtadsoyad.Text, txttckimlikno.Text, txtyas.Text, txtcinsiyet.Text, txttelefon.Text, txtkangrubu.Text,txtsikayet.Text);
            dataGridView1.DataSource = tablo;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                dataGridView1.Rows.RemoveAt(dataGridView1.SelectedRows[0].Index);
            }
            else
            {
                MessageBox.Show("Lütfen silinecek satırı seçin.");
            }

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}

